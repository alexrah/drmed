<div id="featured_slider">
	<div class="inner">
		<div class="staticslider">
			<img src="<?php echo get_template_directory_uri();?>/images/static_image.png" width="960" height="390"/>
		</div>
	</div>
</div>