<div id="featured_slider">
	<div class="slider_wrapper video">
		<?php echo get_option("atp_video_id"); ?>
	</div>
</div>